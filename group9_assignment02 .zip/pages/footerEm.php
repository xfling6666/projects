<footer>
  &copy; <?php echo date('Y'); ?> Book Inventory, 2023 Copyright
</footer>

</body>
</html>




